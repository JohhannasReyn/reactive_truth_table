# Docker Dev Env for JS

## **Project:** Reactive Truth Table Generator

### ***Premise:*** The idea of this web app is to provide the user with a truth table generator that is
###                dynamically consructed from a logical sentence no matter the progamming language used
###                or even if plain english is used. The web app should accurately parse the sentence or
###                string the user has provided in the conditional field for logical opperand, and
###                variables. Then using the deconstructed opperand, construct a truth table and supply
###                the values for each variable to output the entire truth table for the user to verify
###                if the intended logical sentence produces the desired resultant logic.


# Running tests

This command builds a docker image with the code of this repository and runs the repository's tests

```sh
./build_docker.sh reactive_truth_table
docker run -t reactive_truth_table ./run_tests.sh
```

```
[+] Building 0.1s (10/10) FINISHED                                                                   docker:default
 => [internal] load build definition from Dockerfile                                                           0.0s
 => => transferring dockerfile: 226B                                                                           0.0s
 => [internal] load metadata for docker.io/library/node:22.14.0-alpine3.21@sha256:9bef0ef1e268f60627da9ba7d76  0.0s
 => [internal] load .dockerignore                                                                              0.0s
 => => transferring context: 154B                                                                              0.0s
 => [1/5] FROM docker.io/library/node:22.14.0-alpine3.21@sha256:9bef0ef1e268f60627da9ba7d7605e8831d5b56ad0748  0.0s
 => [internal] load build context                                                                              0.0s
 => => transferring context: 1.07kB                                                                            0.0s
 => CACHED [2/5] WORKDIR /app                                                                                  0.0s
 => CACHED [3/5] COPY package.json package-lock.json .                                                         0.0s
 => CACHED [4/5] RUN npm install                                                                               0.0s
 => CACHED [5/5] COPY . .                                                                                      0.0s
 => exporting to image                                                                                         0.0s
 => => exporting layers                                                                                        0.0s
 => => writing image sha256:80007dbaeba9813527f4a4e663e6d773256f6e42f1b3c3fdf713fe45b4897c2f                   0.0s
 => => naming to docker.io/library/reactive_truth_table                                                                      0.0s


> reactive-truth-table@0.0.0 test


```

# Running a specific test

This example runs all tests matching the name "basic":

```sh
./build_docker.sh reactive_truth_table
docker run -t reactive_truth_table ./run_tests.sh basic
```


# Running a vite dev server

Run this command to enable hot reloading via docker.

```sh
./build_docker.sh reactive_truth_table
docker run --network=host -v .:/app -it reactive_truth_table npm exec vite dev --host
```
